import{M as t}from"./index-DAsNhDAW.js";function e(){return t("/api/Common/UserOnline/List")}export{e as l};
